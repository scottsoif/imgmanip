# tools/cmake

This repository hosts the `tools/cmake` Boost submodule, containing experimental CMake support infrastructure for Boost.

Note that building Boost with CMake _does not work yet and is not supported_. The supported way to build Boost is [with `b2`](https://www.boost.org/more/getting_started/index.html).
